"use strict";

(() => {
  const APP_ID = "pocketblocks";
  const BOARD_W = 10;
  const BOARD_H = 20;
  const assetBase = new URL(".", document.currentScript.src);
  const iconUrl = new URL("../assets/icon.svg", assetBase).href;
  const splashUrl = new URL("../assets/splash-screen.jpg", assetBase).href;

  const COLORS = [
    "#090712", "#55d8ee", "#f5b83d", "#8067ed", "#21b88c",
    "#ef5d67", "#6b9dff", "#ff9d58", "#7f7a8d"
  ];

  const SHAPES = [null,
    [
      [[0,1],[1,1],[2,1],[3,1]], [[2,0],[2,1],[2,2],[2,3]],
      [[0,2],[1,2],[2,2],[3,2]], [[1,0],[1,1],[1,2],[1,3]]
    ],
    [
      [[1,0],[2,0],[1,1],[2,1]], [[1,0],[2,0],[1,1],[2,1]],
      [[1,0],[2,0],[1,1],[2,1]], [[1,0],[2,0],[1,1],[2,1]]
    ],
    [
      [[1,0],[0,1],[1,1],[2,1]], [[1,0],[1,1],[2,1],[1,2]],
      [[0,1],[1,1],[2,1],[1,2]], [[1,0],[0,1],[1,1],[1,2]]
    ],
    [
      [[1,0],[2,0],[0,1],[1,1]], [[1,0],[1,1],[2,1],[2,2]],
      [[1,1],[2,1],[0,2],[1,2]], [[0,0],[0,1],[1,1],[1,2]]
    ],
    [
      [[0,0],[1,0],[1,1],[2,1]], [[2,0],[1,1],[2,1],[1,2]],
      [[0,1],[1,1],[1,2],[2,2]], [[1,0],[0,1],[1,1],[0,2]]
    ],
    [
      [[0,0],[0,1],[1,1],[2,1]], [[1,0],[2,0],[1,1],[1,2]],
      [[0,1],[1,1],[2,1],[2,2]], [[1,0],[1,1],[0,2],[1,2]]
    ],
    [
      [[2,0],[0,1],[1,1],[2,1]], [[1,0],[1,1],[1,2],[2,2]],
      [[0,1],[1,1],[2,1],[0,2]], [[0,0],[1,0],[1,1],[1,2]]
    ]
  ];

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function button(text, className) {
    const node = element("button", className, text);
    node.type = "button";
    return node;
  }

  function decodeCells(encoded) {
    const cells = new Uint8Array(BOARD_W * BOARD_H);
    if (typeof encoded !== "string") return cells;
    const limit = Math.min(cells.length, encoded.length);
    for (let i = 0; i < limit; i += 1) {
      const value = Number.parseInt(encoded[i], 16);
      cells[i] = Number.isFinite(value) ? value : 0;
    }
    return cells;
  }

  function drawBoard(canvas, player, compact) {
    const width = compact ? 90 : 300;
    const height = compact ? 180 : 600;
    const scale = Math.max(1, window.devicePixelRatio || 1);
    const pixelWidth = Math.round(width * scale);
    const pixelHeight = Math.round(height * scale);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }

    const context = canvas.getContext("2d", { alpha: false });
    if (!context) return;
    context.setTransform(scale, 0, 0, scale, 0, 0);
    const cellW = width / BOARD_W;
    const cellH = height / BOARD_H;
    const boardGradient = context.createLinearGradient(0, 0, 0, height);
    boardGradient.addColorStop(0, "#18132b");
    boardGradient.addColorStop(1, COLORS[0]);
    context.fillStyle = boardGradient;
    context.fillRect(0, 0, width, height);

    const paintCell = (x, y, color) => {
      const inset = compact ? 0.5 : 1;
      const px = x * cellW + inset;
      const py = y * cellH + inset;
      const blockW = Math.max(1, cellW - inset * 2);
      const blockH = Math.max(1, cellH - inset * 2);
      context.fillStyle = color;
      context.fillRect(px, py, blockW, blockH);
      context.fillStyle = "rgba(255,255,255,0.20)";
      context.fillRect(px + 1, py + 1, Math.max(1, blockW - 2), Math.max(1, blockH * 0.16));
      context.fillStyle = "rgba(0,0,0,0.20)";
      context.fillRect(px + 1, py + blockH * 0.82, Math.max(1, blockW - 2), Math.max(1, blockH * 0.14));
    };

    const cells = decodeCells(player && player.cells);
    for (let y = 0; y < BOARD_H; y += 1) {
      for (let x = 0; x < BOARD_W; x += 1) {
        const value = cells[y * BOARD_W + x];
        if (!value) continue;
        paintCell(x, y, COLORS[value] || COLORS[8]);
      }
    }

    if (player && player.active && player.alive !== false) {
      const active = player.active;
      const rotations = SHAPES[active.type];
      const shape = rotations && rotations[active.rotation & 3];
      if (shape) {
        const activeColor = COLORS[active.type] || COLORS[8];
        for (const [shapeX, shapeY] of shape) {
          const x = active.x + shapeX;
          const y = active.y + shapeY;
          if (x >= 0 && x < BOARD_W && y >= 0 && y < BOARD_H) {
            paintCell(x, y, activeColor);
          }
        }
      }
    }

    context.strokeStyle = "rgba(255,255,255,0.07)";
    context.lineWidth = 1;
    for (let x = 1; x < BOARD_W; x += 1) {
      context.beginPath();
      context.moveTo(x * cellW, 0);
      context.lineTo(x * cellW, height);
      context.stroke();
    }
    for (let y = 1; y < BOARD_H; y += 1) {
      context.beginPath();
      context.moveTo(0, y * cellH);
      context.lineTo(width, y * cellH);
      context.stroke();
    }
  }

  window.PocketArcadeApps = window.PocketArcadeApps || {};
  window.PocketArcadeApps[APP_ID] = {
    mount(container, arcade) {
      const cachedMatch = arcade.game.currentMatch();
      let matchState = cachedMatch && cachedMatch.you && cachedMatch.you.role !== "none"
        ? cachedMatch
        : null;
      const cachedSnapshot = arcade.game.currentSnapshot();
      let snapshotEnvelope = matchState && cachedSnapshot &&
        cachedSnapshot.matchId === matchState.matchId ? cachedSnapshot : null;
      let resultEnvelope = null;
      let latestSnapshotRevision = snapshotEnvelope &&
        Number.isFinite(snapshotEnvelope.revision) ? snapshotEnvelope.revision : -1;
      let disposed = false;
      let joinPending = false;
      const stops = [];
      const held = new Set();
      const timers = new Set();
      const pendingActions = [];
      const activePointers = new Map();
      const lastOneShotAt = new Map();
      const lastRepeatPressAt = new Map();
      const retiredMatchIds = new Set();
      const retiredMatchOrder = [];
      const COMMAND_INTERVAL_MS = 70;
      const REPEAT_PRESS_DEBOUNCE_MS = 90;
      const ONE_SHOT_DEBOUNCE_MS = 140;
      const HARD_DROP_DEBOUNCE_MS = 240;
      const MAX_PENDING_ACTIONS = 3;
      const MAX_RETIRED_MATCHES = 8;
      let inputTimer = null;
      let lastCommandSentAt = -COMMAND_INTERVAL_MS;
      let heldCursor = 0;
      let fitFrame = null;
      let fitObserver = null;
      let lastFitHeight = -1;
      let lastFitWidth = -1;
      let lastBoardHeight = -1;
      let lastBoardWidth = -1;
      let stableFrame = null;
      let stableViewportWidth = -1;
      let stableViewportHeight = -1;
      let stableContainerWidth = -1;
      let stableContainerHeight = -1;
      const MIN_ACTIVE_BOARD_HEIGHT = 240;
      let wasRoundActive = false;

      const root = element("section", "pocketblocks");
      const topbar = element("div", "pb-topbar");
      const brand = element("div", "pb-brand");
      const icon = document.createElement("img");
      icon.className = "pb-icon";
      icon.src = iconUrl;
      icon.alt = "";
      const title = element("div", "pb-title", "PocketBlocks");
      brand.append(icon, title);
      const status = element("div", "pb-status", "Choose Join to play.");
      status.setAttribute("aria-live", "polite");
      const fullscreenButton = button("Full screen", "pb-fullscreen-button");
      fullscreenButton.setAttribute("aria-label", "Enter game full screen");
      const topbarTools = element("div", "pb-topbar-tools");
      topbarTools.append(status, fullscreenButton);
      topbar.append(brand, topbarTools);

      const splash = element("section", "pb-splash");
      const splashArtWrap = element("div", "pb-splash-art-wrap");
      const splashArt = document.createElement("img");
      splashArt.className = "pb-splash-art";
      splashArt.src = splashUrl;
      splashArt.alt = "PocketBlocks splash artwork";
      splashArtWrap.append(splashArt);
      const splashBody = element("div", "pb-splash-body");
      const splashKicker = element("div", "pb-splash-kicker", "MULTIPLAYER PUZZLE BATTLE");
      const splashTitle = element("h1", "pb-splash-title", "PocketBlocks");
      const splashText = element("p", "pb-splash-text", "Stack fast, clear lines and send garbage to every rival. Join a match, ready up, and survive longer than the rest.");
      const splashMeta = element("div", "pb-splash-meta");
      splashMeta.append(
        element("span", "pb-splash-pill", "2–4 players"),
        element("span", "pb-splash-pill", "Realtime battle"),
        element("span", "pb-splash-pill", "Spectators allowed")
      );
      const splashDetailList = element("ul", "pb-splash-details");
      [
        "Clear lines to keep your board safe.",
        "Triple and quad clears send garbage to every rival.",
        "When everyone joined is ready, the round begins automatically."
      ].forEach((line) => {
        splashDetailList.append(element("li", "pb-splash-detail", line));
      });
      const splashActions = element("div", "pb-splash-actions");
      const splashJoinButton = button("Join battle", "pb-primary pb-splash-join");
      splashActions.append(splashJoinButton);
      splashBody.append(splashKicker, splashTitle, splashText, splashMeta, splashDetailList, splashActions);
      splash.append(splashArtWrap, splashBody);

      const actions = element("div", "pb-actions");
      const joinButton = button("Join battle", "pb-primary");
      const readyButton = button("Ready", "pb-primary");
      const claimButton = button("Claim controls", "pb-claim");
      const leaveButton = button("Leave", "pb-danger");
      const againButton = button("Play again", "pb-primary");
      actions.append(joinButton, readyButton, claimButton, leaveButton, againButton);

      const layout = element("div", "pb-layout");
      const playersPanel = element("section", "pb-players-panel");
      const playersHeading = element("div", "pb-players-heading");
      playersHeading.append(
        element("div", "pb-section-title", "Players"),
        element("div", "pb-player-count", "Waiting for players")
      );
      const opponents = element("div", "pb-opponents");
      playersPanel.append(playersHeading, opponents);

      const stage = element("div", "pb-stage");
      const boardWrap = element("div", "pb-board-wrap");
      const board = element("canvas", "pb-board");
      board.setAttribute("aria-label", "Your PocketBlocks board");
      const boardOverlay = element("div", "pb-board-overlay");
      const overlayKicker = element("div", "pb-overlay-kicker", "POCKETBLOCKS");
      const overlayTitle = element("div", "pb-overlay-title", "Join the battle");
      const overlayText = element("div", "pb-overlay-text", "Take a seat, ready up and outlast your rivals.");
      boardOverlay.append(overlayKicker, overlayTitle, overlayText);
      boardWrap.append(board, boardOverlay);
      const boardViewport = element("div", "pb-board-viewport");
      boardViewport.append(boardWrap);

      const stats = element("div", "pb-stats");
      const score = element("span", "pb-stat", "Score 0");
      const lines = element("span", "pb-stat", "Lines 0");
      const garbage = element("span", "pb-stat", "Garbage 0");
      stats.append(score, lines, garbage);
      stage.append(boardViewport, stats);
      layout.append(playersPanel, stage);

      const controls = element("div", "pb-controls");
      const leftButton = button("◀", "pb-control");
      const rotateButton = button("↻", "pb-control");
      const rightButton = button("▶", "pb-control");
      const downButton = button("▼", "pb-control");
      const dropButton = button("DROP", "pb-control pb-primary");
      leftButton.setAttribute("aria-label", "Move left");
      rotateButton.setAttribute("aria-label", "Rotate clockwise");
      rightButton.setAttribute("aria-label", "Move right");
      downButton.setAttribute("aria-label", "Soft drop");
      dropButton.setAttribute("aria-label", "Hard drop");
      controls.append(leftButton, rotateButton, rightButton, downButton, dropButton);

      const controlPanel = element("section", "pb-control-panel");
      const controlCopy = element("div", "pb-control-copy");
      const controlKicker = element("div", "pb-control-kicker", "CONTROLS");
      const controlTitle = element("div", "pb-control-title", "Join the battle");
      const controlHint = element("div", "pb-control-hint", "Your controls will appear when the round starts.");
      controlCopy.append(controlKicker, controlTitle, controlHint);
      controlPanel.append(controlCopy, controls);

      const help = element(
        "div",
        "pb-help",
        "Keyboard: arrows move, Z/X rotate, Space drops. Clearing 3 or 4 lines sends cleared lines minus one to every opponent."
      );
      root.append(topbar, splash, layout, controlPanel, actions, help);
      container.replaceChildren(root);

      function layoutViewportSize() {
        return {
          width: Math.max(280, Math.floor(
            document.documentElement.clientWidth || window.innerWidth || 0
          )),
          height: Math.max(320, Math.floor(
            document.documentElement.clientHeight || window.innerHeight || 0
          ))
        };
      }

      function measureStableFrame(forceViewport) {
        const viewport = layoutViewportSize();
        const orientationChanged = stableViewportWidth > 0 &&
          ((viewport.width > viewport.height) !==
           (stableViewportWidth > stableViewportHeight));
        const widthChanged = stableViewportWidth < 0 ||
          Math.abs(viewport.width - stableViewportWidth) > 40;
        if (forceViewport || widthChanged || orientationChanged) {
          stableViewportWidth = viewport.width;
          stableViewportHeight = viewport.height;
        }

        const scrollX = window.scrollX || document.documentElement.scrollLeft || 0;
        const scrollY = window.scrollY || document.documentElement.scrollTop || 0;
        const containerRect = container.getBoundingClientRect();
        stableContainerWidth = containerRect.width;
        stableContainerHeight = containerRect.height;
        let top = containerRect.top + scrollY;
        let left = containerRect.left + scrollX;
        let right = containerRect.right + scrollX;
        let bottom = Number.POSITIVE_INFINITY;
        let ancestor = container;

        while (ancestor && ancestor !== document.documentElement) {
          const style = window.getComputedStyle(ancestor);
          const clipsY = /(auto|scroll|hidden|clip)/.test(style.overflowY);
          const clipsX = /(auto|scroll|hidden|clip)/.test(style.overflowX);
          if (clipsY || clipsX) {
            const rect = ancestor.getBoundingClientRect();
            if (clipsY && rect.height > 0) {
              bottom = Math.min(bottom, rect.bottom + scrollY);
            }
            if (clipsX && rect.width > 0) {
              left = Math.max(left, rect.left + scrollX);
              right = Math.min(right, rect.right + scrollX);
            }
          }
          ancestor = ancestor.parentElement;
        }

        stableFrame = { top, left, right, bottom };
      }

      function syncViewportFit() {
        if (disposed) return;
        if (!stableFrame) measureStableFrame(true);

        const frameHeight = Number.isFinite(stableFrame.bottom)
          ? stableFrame.bottom - stableFrame.top
          : Number.POSITIVE_INFINITY;
        const viewportHeight = Math.max(320, stableViewportHeight);
        const viewportWidth = Math.max(280, stableViewportWidth);
        const viewportAvailableHeight = Math.max(320,
          viewportHeight - Math.max(0, stableFrame.top));
        const viewportAvailableWidth = Math.max(280,
          viewportWidth - Math.max(0, stableFrame.left));
        const availableHeight = Math.max(320, Math.floor(
          Math.min(viewportAvailableHeight, frameHeight)
        ));
        const availableWidth = Math.max(280, Math.floor(
          Math.min(viewportAvailableWidth, stableFrame.right - stableFrame.left)
        ));

        if (Math.abs(availableHeight - lastFitHeight) > 1) {
          lastFitHeight = availableHeight;
          root.style.setProperty("--pb-fit-height", `${availableHeight}px`);
        }
        if (Math.abs(availableWidth - lastFitWidth) > 1) {
          lastFitWidth = availableWidth;
          root.style.setProperty("--pb-fit-width", `${availableWidth}px`);
        }

        // Active play always keeps the controls below the board. Fullscreen
        // provides the extra space; landscape must not move controls sideways.
        root.classList.remove("is-landscape-play");
        root.classList.toggle("is-height-tight", availableHeight < 720);
        root.classList.toggle("is-height-very-tight", availableHeight < 620);
        root.classList.toggle("is-height-ultra-tight", availableHeight < 470);
        root.classList.toggle("is-width-tight", availableWidth < 430);

        const slotRect = boardViewport.getBoundingClientRect();
        if (slotRect.width > 0 && slotRect.height > 0) {
          const fittedHeight = Math.max(30,
            Math.floor(Math.min(slotRect.height, slotRect.width * 2)));
          const activePlay = root.classList.contains("is-active-play");
          const boardHeight = fittedHeight;
          const boardWidth = Math.max(15, Math.floor(boardHeight / 2));
          root.classList.toggle("is-board-constrained",
            activePlay && boardHeight < MIN_ACTIVE_BOARD_HEIGHT);
          if (Math.abs(boardHeight - lastBoardHeight) > 1 ||
              Math.abs(boardWidth - lastBoardWidth) > 1) {
            lastBoardHeight = boardHeight;
            lastBoardWidth = boardWidth;
            boardWrap.style.width = `${boardWidth}px`;
            boardWrap.style.height = `${boardHeight}px`;
          }
        }
      }

      function scheduleViewportFit() {
        if (disposed || fitFrame !== null) return;
        fitFrame = window.requestAnimationFrame(() => {
          fitFrame = null;
          syncViewportFit();
        });
      }

      const onViewportResize = () => {
        const viewport = layoutViewportSize();
        const orientationChanged = stableViewportWidth > 0 &&
          ((viewport.width > viewport.height) !==
           (stableViewportWidth > stableViewportHeight));
        if (orientationChanged || Math.abs(viewport.width - stableViewportWidth) > 40) {
          measureStableFrame(true);
        }
        scheduleViewportFit();
      };
      window.addEventListener("resize", onViewportResize);
      if (typeof ResizeObserver === "function") {
        fitObserver = new ResizeObserver(() => {
          const rect = container.getBoundingClientRect();
          const widthChanged = stableContainerWidth < 0 ||
            Math.abs(rect.width - stableContainerWidth) > 20;
          const enteredFullscreen = root.classList.contains("is-fullscreen") &&
            Math.abs(rect.height - stableContainerHeight) > 40;
          if (widthChanged || enteredFullscreen) {
            measureStableFrame(true);
            scheduleViewportFit();
          }
        });
        fitObserver.observe(container);
      }
      measureStableFrame(true);
      scheduleViewportFit();

      function payload() {
        return snapshotEnvelope && snapshotEnvelope.payload && typeof snapshotEnvelope.payload === "object"
          ? snapshotEnvelope.payload
          : null;
      }

      function ownSeat() {
        return matchState && matchState.you && matchState.you.role === "player"
          ? matchState.you.seat
          : null;
      }

      function playerBySeat(seat) {
        const state = payload();
        if (!state || !Array.isArray(state.players)) return null;
        return state.players.find((player) => player.seat === seat) || null;
      }

      function ownPlayer() {
        return playerBySeat(ownSeat());
      }

      function displayName(player) {
        return player && typeof player.nickname === "string" && player.nickname
          ? player.nickname
          : "Player";
      }

      function profileForSeat(seat) {
        if (!matchState || !Array.isArray(matchState.seats)) return null;
        const matchSeat = matchState.seats.find((entry) => entry.seat === seat);
        return matchSeat && matchSeat.player ? matchSeat.player : null;
      }

      function avatarUrlFor(player) {
        const matchProfile = player ? profileForSeat(player.seat) : null;
        const ownProfile = player && player.seat === ownSeat() && arcade.profile
          ? arcade.profile
          : null;
        for (const profile of [matchProfile, ownProfile, player]) {
          if (profile && typeof profile.avatarUrl === "string" && profile.avatarUrl) {
            return profile.avatarUrl;
          }
        }
        return "";
      }

      function makeAvatar(player) {
        const wrapper = element("div", "pb-avatar");
        const avatarUrl = avatarUrlFor(player);
        const name = displayName(player);
        if (avatarUrl) {
          const image = document.createElement("img");
          image.src = avatarUrl;
          image.alt = `${name} profile avatar`;
          image.addEventListener("error", () => {
            image.remove();
            wrapper.textContent = name.trim().slice(0, 1).toUpperCase() || "?";
          }, { once: true });
          wrapper.append(image);
        } else {
          wrapper.textContent = name.trim().slice(0, 1).toUpperCase() || "?";
          wrapper.setAttribute("aria-label", `${name} profile avatar`);
        }
        return wrapper;
      }

      function isFinished() {
        return Boolean(resultEnvelope || (matchState && matchState.state === "finished"));
      }

      function canControl() {
        const state = payload();
        const me = ownPlayer();
        return Boolean(
          matchState &&
          matchState.you &&
          matchState.you.role === "player" &&
          matchState.you.controller &&
          state &&
          state.phase === "playing" &&
          me &&
          me.alive !== false
        );
      }

      function setStatus(message, kind) {
        status.textContent = message;
        status.dataset.state = kind || "";
      }

      function setFullscreenState(fullscreen) {
        const active = Boolean(fullscreen);
        root.classList.toggle("is-fullscreen", active);
        fullscreenButton.textContent = active ? "Full screen on" : "Full screen";
        fullscreenButton.setAttribute("aria-label", active ? "Game is in full screen" : "Enter game full screen");
        measureStableFrame(true);
        scheduleViewportFit();
      }

      function sendActionNow(action, data) {
        if (!matchState || !matchState.matchId || !canControl() || disposed) return false;
        const sent = arcade.game.send(matchState.matchId, action, data || {});
        if (!sent) setStatus("Unable to send control.", "error");
        return sent;
      }

      function clearInputState() {
        held.clear();
        pendingActions.length = 0;
        activePointers.clear();
        heldCursor = 0;
        if (inputTimer !== null) {
          window.clearTimeout(inputTimer);
          timers.delete(inputTimer);
          inputTimer = null;
        }
      }

      function scheduleInputPump(delayMs) {
        if (inputTimer !== null || disposed) return;
        inputTimer = window.setTimeout(runInputPump, Math.max(0, delayMs));
        timers.add(inputTimer);
      }

      function runInputPump() {
        if (inputTimer !== null) {
          timers.delete(inputTimer);
          inputTimer = null;
        }
        if (!canControl() || disposed) {
          clearInputState();
          return;
        }

        const now = window.performance && typeof window.performance.now === "function"
          ? window.performance.now()
          : Date.now();
        const remaining = COMMAND_INTERVAL_MS - (now - lastCommandSentAt);
        if (remaining > 0) {
          scheduleInputPump(remaining);
          return;
        }

        let next = pendingActions.shift() || null;
        if (!next && held.size) {
          const actions = [...held];
          const action = actions[heldCursor % actions.length];
          heldCursor = (heldCursor + 1) % actions.length;
          next = { action, data: {} };
        }
        if (next && sendActionNow(next.action, next.data)) {
          lastCommandSentAt = now;
        }
        if (pendingActions.length || held.size) {
          scheduleInputPump(COMMAND_INTERVAL_MS);
        }
      }

      function sendAction(action, data) {
        if (!canControl() || disposed) return false;
        if (pendingActions.length >= MAX_PENDING_ACTIONS) {
          return false;
        }
        pendingActions.push({ action, data: data || {} });
        scheduleInputPump(0);
        return true;
      }

      function sendOneShot(action, data) {
        const now = window.performance && typeof window.performance.now === "function"
          ? window.performance.now()
          : Date.now();
        const interval = action === "hard-drop"
          ? HARD_DROP_DEBOUNCE_MS
          : ONE_SHOT_DEBOUNCE_MS;
        const previous = lastOneShotAt.get(action);
        if (Number.isFinite(previous) && now - previous < interval) return false;
        const alreadyQueued = pendingActions.some((entry) => entry.action === action);
        if (alreadyQueued) return false;
        if (!sendAction(action, data)) return false;
        lastOneShotAt.set(action, now);
        return true;
      }

      function retireMatch(matchId) {
        if (!matchId || retiredMatchIds.has(matchId)) return;
        retiredMatchIds.add(matchId);
        retiredMatchOrder.push(matchId);
        while (retiredMatchOrder.length > MAX_RETIRED_MATCHES) {
          retiredMatchIds.delete(retiredMatchOrder.shift());
        }
      }

      function clearMatchState(retireCurrent) {
        if (retireCurrent && matchState && matchState.matchId) {
          retireMatch(matchState.matchId);
        }
        matchState = null;
        snapshotEnvelope = null;
        resultEnvelope = null;
        latestSnapshotRevision = -1;
        wasRoundActive = false;
        clearInputState();
      }

      function renderPlayers(me) {
        opponents.replaceChildren();
        const state = payload();
        const gamePlayers = state && Array.isArray(state.players) ? state.players : [];
        const gamePlayersBySeat = new Map(gamePlayers.map((player) => [player.seat, player]));
        const seats = matchState && Array.isArray(matchState.seats) ? matchState.seats : [];
        const localSeat = ownSeat();
        const platformWaiting = Boolean(matchState && matchState.state === "waiting");

        const occupied = seats
          .filter((seat) => seat && seat.player)
          .map((seat) => {
            const gamePlayer = gamePlayersBySeat.get(seat.seat);
            return {
              seat: seat.seat,
              ready: Boolean(seat.ready),
              connected: seat.connected !== false,
              player: gamePlayer || {
                seat: seat.seat,
                nickname: seat.player.nickname || "Player",
                avatarUrl: seat.player.avatarUrl || "",
                alive: true,
                score: 0,
                lines: 0,
                pendingGarbage: 0
              }
            };
          });

        for (const gamePlayer of gamePlayers) {
          if (!occupied.some((entry) => entry.seat === gamePlayer.seat)) {
            occupied.push({
              seat: gamePlayer.seat,
              ready: false,
              connected: gamePlayer.connected !== false,
              player: gamePlayer
            });
          }
        }

        occupied.sort((a, b) => {
          if (a.seat === localSeat) return -1;
          if (b.seat === localSeat) return 1;
          return a.seat - b.seat;
        });

        for (const entry of occupied) {
          const player = entry.player;
          const item = element("div", `pb-opponent seat-${entry.seat}`);
          if (entry.seat === localSeat) item.classList.add("is-self");
          if (entry.connected === false) item.classList.add("is-disconnected");
          const info = element("div", "pb-player-info");
          const nameRow = element("div", "pb-player-name-row");
          nameRow.append(element("div", "pb-player-name", displayName(player)));
          if (entry.seat === localSeat) {
            nameRow.append(element("span", "pb-player-badge", "YOU"));
          } else {
            nameRow.append(element("span", "pb-player-badge", `P${entry.seat}`));
          }
          const knockedOut = player.alive === false &&
            (state && (state.phase === "playing" || state.phase === "finished"));
          let metaText;
          if (knockedOut) {
            metaText = "Knocked out";
          } else if (state && (state.phase === "playing" || state.phase === "finished")) {
            metaText = `${player.lines || 0} lines · ${player.score || 0} pts`;
          } else if (entry.connected === false) {
            metaText = "Reconnecting";
          } else {
            metaText = entry.ready ? "Ready" : "Getting ready";
          }
          const meta = element("div", "pb-player-meta", metaText);
          if (knockedOut) meta.classList.add("is-out");
          info.append(nameRow, meta);
          item.append(makeAvatar(player), info);
          opponents.append(item);
        }

        if (platformWaiting) {
          for (const seat of seats) {
            if (!seat || seat.player) continue;
            const item = element("div", `pb-open-seat seat-${seat.seat}`);
            const seatMark = element("div", "pb-open-seat-mark", `P${seat.seat}`);
            const info = element("div", "pb-player-info");
            info.append(
              element("div", "pb-player-name", "Open Seat"),
              element("div", "pb-player-meta", "Waiting for a player")
            );
            item.append(seatMark, info);
            opponents.append(item);
          }
        }

        const spectators = matchState && Array.isArray(matchState.spectators)
          ? matchState.spectators
          : [];
        if (!platformWaiting) {
          for (const spectator of spectators) {
            const spectatorPlayer = {
              nickname: spectator.nickname || "Spectator",
              avatarUrl: spectator.avatarUrl || ""
            };
            const item = element("div", "pb-spectator");
            const info = element("div", "pb-player-info");
            info.append(element("div", "pb-player-name", displayName(spectatorPlayer)));
            item.append(makeAvatar(spectatorPlayer), info);
            opponents.append(item);
          }
        }

        if (!opponents.children.length) {
          opponents.append(element("div", "pb-empty-players", "Join to see the player line-up."));
        }
      }

      function resultWinnerName() {
        const result = resultEnvelope && resultEnvelope.payload;
        const placements = result && Array.isArray(result.placements) ? result.placements : [];
        const winner = placements.find((placement) => placement.place === 1);
        return winner && winner.nickname ? winner.nickname : null;
      }

      function render() {
        const state = payload();
        const me = ownPlayer();
        const role = matchState && matchState.you ? matchState.you.role : "none";
        const platformPhase = matchState ? matchState.state : "none";
        const gamePhase = state ? state.phase : "waiting";
        const finished = isFinished();
        const controller = Boolean(matchState && matchState.you && matchState.you.controller);

        const isStartScreen = !matchState;
        splash.classList.toggle("pb-hidden", !isStartScreen);
        layout.classList.toggle("pb-hidden", isStartScreen);
        actions.classList.toggle("pb-hidden", isStartScreen);

        joinButton.classList.toggle("pb-hidden", Boolean(matchState));
        readyButton.classList.toggle("pb-hidden", !matchState || role !== "player" || platformPhase !== "waiting");
        claimButton.classList.toggle("pb-hidden", !matchState || role !== "player" || controller || finished);
        leaveButton.classList.toggle("pb-hidden", !matchState || finished);
        againButton.classList.toggle("pb-hidden", !finished);

        const ownMatchSeat = matchState && Array.isArray(matchState.seats)
          ? matchState.seats.find((seat) => seat.seat === ownSeat())
          : null;
        readyButton.disabled = Boolean(ownMatchSeat && ownMatchSeat.ready);
        readyButton.textContent = ownMatchSeat && ownMatchSeat.ready ? "Ready ✓" : "Ready";

        const enabled = canControl();
        const showPlayField = Boolean(
          matchState && (finished || platformPhase === "playing" ||
            gamePhase === "countdown" || gamePhase === "playing" ||
            gamePhase === "finished")
        );
        const showGameControls = Boolean(
          showPlayField && role === "player" && !finished &&
          gamePhase === "playing" && me && me.alive !== false
        );
        stage.classList.toggle("pb-hidden", !showPlayField);
        controlPanel.classList.toggle("pb-hidden", !showPlayField);
        help.classList.toggle("pb-hidden", !showPlayField || isStartScreen);
        stage.setAttribute("aria-hidden", showPlayField ? "false" : "true");
        root.classList.toggle("is-lobby", !showPlayField && !isStartScreen);
        root.classList.toggle("is-start-screen", isStartScreen);
        controls.classList.toggle("pb-hidden", !showGameControls);
        for (const control of [leftButton, rotateButton, rightButton, downButton, dropButton]) {
          control.disabled = !enabled;
          control.setAttribute("aria-disabled", enabled ? "false" : "true");
        }

        root.classList.toggle("is-actionable", enabled);
        root.classList.toggle("is-finished", finished);
        root.classList.toggle("is-spectator", role === "spectator");
        root.classList.toggle("is-observer", role === "player" && !controller);
        const roundActive = Boolean(
          matchState && !finished && platformPhase === "playing" &&
          (gamePhase === "countdown" || gamePhase === "playing")
        );
        root.classList.toggle("is-active-play", roundActive);
        if (roundActive && !wasRoundActive && arcade.display &&
            typeof arcade.display.requestFullscreen === "function" &&
            !arcade.display.fullscreen) {
          arcade.display.requestFullscreen();
        }
        wasRoundActive = roundActive;
        root.classList.toggle("needs-control-claim", Boolean(
          matchState && !finished && gamePhase === "playing" &&
          role === "player" && !controller
        ));
        root.dataset.phase = finished ? "finished" : gamePhase;

        boardOverlay.classList.remove("pb-hidden");
        overlayKicker.textContent = "POCKETBLOCKS";

        if (!matchState) {
          setStatus("Choose Join to play.", "");
          controlKicker.textContent = "WELCOME";
          controlTitle.textContent = "Join the battle";
          controlHint.textContent = "Take a seat, ready up and outlast your rivals.";
          overlayTitle.textContent = "Join the battle";
          overlayText.textContent = "Build clean lines and send garbage to every rival.";
        } else if (finished) {
          const winner = resultWinnerName();
          setStatus(winner ? `${winner} wins!` : "Battle finished", "ok");
          controlKicker.textContent = "RESULT";
          controlTitle.textContent = winner ? `${winner} wins` : "Round complete";
          controlHint.textContent = "Start a fresh match when everyone is ready.";
          overlayKicker.textContent = "ROUND COMPLETE";
          overlayTitle.textContent = winner ? `${winner} wins!` : "Battle finished";
          overlayText.textContent = "The final placement is locked in.";
        } else if (role === "spectator") {
          setStatus("Spectating battle", "");
          controlKicker.textContent = "SPECTATING";
          controlTitle.textContent = "Watch the stack rise";
          controlHint.textContent = "Spectators can follow the action but cannot send controls.";
          if (gamePhase === "playing") boardOverlay.classList.add("pb-hidden");
          else {
            overlayTitle.textContent = "Battle starting soon";
            overlayText.textContent = "The players are getting ready.";
          }
        } else if (!controller) {
          setStatus("Your controls are active in another tab", "");
          controlKicker.textContent = "CONTROL";
          controlTitle.textContent = "Watching your seat";
          controlHint.textContent = "Use Take control below to play from this screen.";
          if (gamePhase === "playing") boardOverlay.classList.add("pb-hidden");
          else {
            overlayTitle.textContent = "Ready on another screen";
            overlayText.textContent = "Take control here when you want to play.";
          }
        } else if (platformPhase === "waiting") {
          const occupied = Array.isArray(matchState.seats)
            ? matchState.seats.filter((seat) => seat.player).length
            : 0;
          const ready = Boolean(ownMatchSeat && ownMatchSeat.ready);
          setStatus(
            occupied < 2 ? "Waiting for another player…" :
              ready ? "Ready — waiting for rivals" : "Ready up when prepared",
            ready ? "ok" : ""
          );
          controlKicker.textContent = ready ? "READY" : "NEXT STEP";
          controlTitle.textContent = ready ? "Waiting for rivals" : "Ready up";
          controlHint.textContent = ready
            ? "The round begins when every occupied seat is ready."
            : "Press Ready below when you are set to play.";
          overlayTitle.textContent = occupied < 2 ? "Waiting for rivals" : "Ready when you are";
          overlayText.textContent = occupied < 2
            ? "At least two players are needed to begin."
            : "Every occupied seat must be ready.";
        } else if (gamePhase === "countdown") {
          const count = Math.max(1, Math.ceil((state.countdownMs || 0) / 1000));
          setStatus(`Starting in ${count}…`, "ok");
          controlKicker.textContent = "GET READY";
          controlTitle.textContent = `Starting in ${count}`;
          controlHint.textContent = "Your controls unlock when the countdown ends.";
          overlayKicker.textContent = "GET READY";
          overlayTitle.textContent = String(count);
          overlayText.textContent = "Build fast. Keep the stack low.";
        } else if (gamePhase === "playing") {
          const knockedOut = me && me.alive === false;
          setStatus(knockedOut ? "Knocked out — spectating" : "Battle in progress", knockedOut ? "" : "ok");
          if (knockedOut) {
            controlKicker.textContent = "KNOCKED OUT";
            controlTitle.textContent = "Watch the finish";
            controlHint.textContent = "Your board is locked while the remaining players battle.";
            overlayKicker.textContent = "BATTLE OVER";
            overlayTitle.textContent = "Knocked out";
            overlayText.textContent = "Stay to see the final result.";
          } else {
            controlKicker.textContent = enabled ? "YOUR CONTROLS" : "WAITING";
            controlTitle.textContent = enabled ? "Build fast" : "Controls unavailable";
            controlHint.textContent = enabled
              ? "Move, rotate and drop. Clearing three or four lines attacks every rival."
              : "Take control from the active tab to continue.";
            boardOverlay.classList.add("pb-hidden");
          }
        } else {
          setStatus("Preparing battle…", "");
          controlKicker.textContent = "PREPARING";
          controlTitle.textContent = "Setting the board";
          controlHint.textContent = "The next authoritative state will start the round.";
          overlayTitle.textContent = "Preparing battle";
          overlayText.textContent = "Setting every board for the round.";
        }

        if (showPlayField) {
          drawBoard(board, me || { cells: "" }, false);
          score.textContent = `Score ${me ? me.score || 0 : 0}`;
          lines.textContent = `Lines ${me ? me.lines || 0 : 0}`;
          garbage.textContent = `Garbage ${me ? me.pendingGarbage || 0 : 0}`;
        }
        renderPlayers(me);
        const visiblePlayers = state && Array.isArray(state.players)
          ? state.players.length
          : matchState && Array.isArray(matchState.seats)
            ? matchState.seats.filter((seat) => seat.player).length
            : 0;
        playersHeading.lastChild.textContent = visiblePlayers
          ? `${visiblePlayers} of 4 joined`
          : "Waiting for players";
        scheduleViewportFit();
      }

      function beginHeld(action) {
        if (held.has(action) || !canControl()) return;
        held.add(action);
        scheduleInputPump(0);
      }

      function endHeld(action) {
        held.delete(action);
        if (!held.size && !pendingActions.length && inputTimer !== null) {
          window.clearTimeout(inputTimer);
          timers.delete(inputTimer);
          inputTimer = null;
        }
      }

      function bindPress(control, action, repeat) {
        const down = (event) => {
          event.preventDefault();
          if (event.pointerType === "mouse" && event.button !== 0) return;
          if (activePointers.has(action)) return;
          if (repeat) {
            const now = window.performance && typeof window.performance.now === "function"
              ? window.performance.now()
              : Date.now();
            const previous = lastRepeatPressAt.get(action);
            if (Number.isFinite(previous) && now - previous < REPEAT_PRESS_DEBOUNCE_MS) return;
            lastRepeatPressAt.set(action, now);
          }
          activePointers.set(action, event.pointerId);
          try {
            control.setPointerCapture(event.pointerId);
          } catch (_) {
            // Pointer capture is optional on older embedded browsers.
          }
          if (repeat) beginHeld(action);
          else sendOneShot(action, {});
        };
        const up = (event) => {
          const pointerId = activePointers.get(action);
          if (pointerId !== event.pointerId) return;
          event.preventDefault();
          activePointers.delete(action);
          endHeld(action);
          try {
            if (control.hasPointerCapture(event.pointerId)) {
              control.releasePointerCapture(event.pointerId);
            }
          } catch (_) {
            // Ignore browsers without complete pointer-capture support.
          }
        };
        control.addEventListener("pointerdown", down);
        control.addEventListener("pointerup", up);
        control.addEventListener("pointercancel", up);
        control.addEventListener("lostpointercapture", up);
        return () => {
          control.removeEventListener("pointerdown", down);
          control.removeEventListener("pointerup", up);
          control.removeEventListener("pointercancel", up);
          control.removeEventListener("lostpointercapture", up);
        };
      }

      const unbindControls = [
        bindPress(leftButton, "left", true),
        bindPress(rightButton, "right", true),
        bindPress(downButton, "soft-drop", true),
        bindPress(rotateButton, "rotate-cw", false),
        bindPress(dropButton, "hard-drop", false)
      ];

      const repeatedKeys = new Set(["ArrowLeft", "ArrowRight", "ArrowDown"]);
      const onKeyDown = (event) => {
        const actions = {
          ArrowLeft: "left",
          ArrowRight: "right",
          ArrowDown: "soft-drop",
          ArrowUp: "rotate-cw",
          x: "rotate-cw",
          X: "rotate-cw",
          z: "rotate-ccw",
          Z: "rotate-ccw",
          " ": "hard-drop"
        };
        const action = actions[event.key];
        if (!action) return;
        event.preventDefault();
        if (repeatedKeys.has(event.key)) {
          if (!event.repeat) beginHeld(action);
        } else if (!event.repeat) {
          sendOneShot(action, {});
        }
      };
      const onKeyUp = (event) => {
        if (!repeatedKeys.has(event.key)) return;
        event.preventDefault();
        const actions = {
          ArrowLeft: "left",
          ArrowRight: "right",
          ArrowDown: "soft-drop"
        };
        endHeld(actions[event.key]);
      };
      const onVisibilityChange = () => {
        if (document.hidden) clearInputState();
      };
      const onWindowBlur = () => clearInputState();
      document.addEventListener("keydown", onKeyDown);
      document.addEventListener("keyup", onKeyUp);
      document.addEventListener("visibilitychange", onVisibilityChange);
      window.addEventListener("blur", onWindowBlur);

      function requestJoin(errorMessage) {
        clearMatchState(true);
        lastCommandSentAt = -COMMAND_INTERVAL_MS;
        lastOneShotAt.clear();
        lastRepeatPressAt.clear();
        joinPending = true;
        if (!arcade.game.join(APP_ID)) {
          joinPending = false;
          setStatus(errorMessage, "error");
        }
        render();
      }

      fullscreenButton.addEventListener("click", () => {
        if (!arcade.display || typeof arcade.display.requestFullscreen !== "function") return;
        if (!arcade.display.fullscreen) {
          arcade.display.requestFullscreen();
        }
      });

      joinButton.addEventListener("click", () => {
        requestJoin("Unable to request a match.");
      });
      splashJoinButton.addEventListener("click", () => {
        requestJoin("Unable to request a match.");
      });
      againButton.addEventListener("click", () => {
        requestJoin("Unable to request a new match.");
      });
      readyButton.addEventListener("click", () => {
        if (matchState && !arcade.game.ready(matchState.matchId)) setStatus("Unable to mark ready.", "error");
      });
      claimButton.addEventListener("click", () => {
        if (!matchState || !arcade.game.claimControl(matchState.matchId)) {
          setStatus("Unable to claim controls.", "error");
        }
      });
      leaveButton.addEventListener("click", () => {
        if (matchState && !arcade.game.leave(matchState.matchId)) setStatus("Unable to leave match.", "error");
      });

      stops.push(arcade.game.onMatch((nextMatch) => {
        if (!nextMatch || !nextMatch.matchId) return;
        if (retiredMatchIds.has(nextMatch.matchId)) return;
        const role = nextMatch.you && nextMatch.you.role;
        const previousMatchId = matchState && matchState.matchId;
        const previouslyController = Boolean(
          matchState && matchState.you && matchState.you.controller
        );
        if (role === "none") {
          if (!matchState || nextMatch.matchId === matchState.matchId) {
            retireMatch(nextMatch.matchId);
            clearMatchState(false);
            joinPending = false;
            render();
          }
          return;
        }
        if (matchState && nextMatch.matchId !== matchState.matchId) {
          if (!joinPending) return;
          clearMatchState(true);
        }
        if (!matchState) {
          snapshotEnvelope = null;
          resultEnvelope = null;
          latestSnapshotRevision = -1;
        }
        matchState = nextMatch;
        joinPending = false;
        if (role !== "player" || !nextMatch.you.controller ||
            nextMatch.state !== "playing") {
          clearInputState();
        }
        if (nextMatch.state !== "finished" &&
            nextMatch.you && nextMatch.you.controller &&
            (nextMatch.matchId !== previousMatchId || !previouslyController)) {
          arcade.game.requestSnapshot(nextMatch.matchId);
        }
        render();
      }));

      stops.push(arcade.game.onSnapshot((nextSnapshot) => {
        if (!nextSnapshot || nextSnapshot.appId !== APP_ID ||
            !matchState || nextSnapshot.matchId !== matchState.matchId) return;
        if (Number.isFinite(nextSnapshot.revision) && nextSnapshot.revision < latestSnapshotRevision) return;
        if (Number.isFinite(nextSnapshot.revision)) latestSnapshotRevision = nextSnapshot.revision;
        snapshotEnvelope = nextSnapshot;
        render();
      }));

      stops.push(arcade.game.onEvent((event) => {
        if (!event || !matchState || event.matchId !== matchState.matchId) return;
        if (event.name) setStatus(String(event.name), "ok");
      }));

      stops.push(arcade.game.onResult((result) => {
        if (!result || !matchState || result.matchId !== matchState.matchId) return;
        resultEnvelope = result;
        render();
      }));

      stops.push(arcade.game.onError((error) => {
        if (error && error.matchId &&
            (!matchState || error.matchId !== matchState.matchId)) return;
        if (!error || !error.matchId) joinPending = false;
        if (error && (error.code === "rate_limited" ||
            error.code === "queue_full")) {
          clearInputState();
        }
        if (error && error.code === "runtime_failed") {
          setStatus("PocketBlocks rules stopped safely. Start a fresh match after checking the device log.", "error");
        } else {
          setStatus(error && error.message ? String(error.message) : "Game operation rejected.", "error");
        }
      }));

      stops.push(arcade.onConnection((connection) => {
        if (connection !== "connected") clearInputState();
      }));

      if (arcade.display && typeof arcade.display.onFullscreenChange === "function") {
        stops.push(arcade.display.onFullscreenChange(setFullscreenState));
        setFullscreenState(arcade.display.fullscreen);
      } else {
        fullscreenButton.classList.add("pb-hidden");
      }

      if (matchState && matchState.matchId &&
          matchState.state !== "finished") {
        arcade.game.requestSnapshot(matchState.matchId);
      }
      render();

      return () => {
        disposed = true;
        for (const stop of stops) stop();
        for (const unbind of unbindControls) unbind();
        clearInputState();
        for (const timer of timers) {
          window.clearTimeout(timer);
        }
        timers.clear();
        document.removeEventListener("keydown", onKeyDown);
        document.removeEventListener("keyup", onKeyUp);
        document.removeEventListener("visibilitychange", onVisibilityChange);
        window.removeEventListener("blur", onWindowBlur);
        window.removeEventListener("resize", onViewportResize);
        if (fitObserver) fitObserver.disconnect();
        if (fitFrame !== null) window.cancelAnimationFrame(fitFrame);
        fitFrame = null;
        container.replaceChildren();
      };
    }
  };
})();
