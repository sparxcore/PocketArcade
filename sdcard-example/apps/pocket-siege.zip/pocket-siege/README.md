# Pocket Siege

Pocket Siege is an original two-player slingshot fortress battle for PocketArcade firmware 0.3.0.

## Install

Copy the complete `pocket-siege` directory to:

```text
/apps/pocket-siege/
```

Then remount or restart PocketArcade so the application catalogue is rescanned. Hard-reload each phone browser after updating the client files.

## Package contents

```text
pocket-siege/
├── manifest.json
├── client/
│   ├── app.js
│   └── app.css
├── assets/
│   ├── icon.svg
│   └── splash.jpg
└── server/
    └── main.lua
```

## Match flow

1. The app opens on a PocketArcade-style splash page with game details and a **Join game** button.
2. Two players join the lobby and use the platform Ready button.
3. Each player privately orders Boulder, Splitter, and Bomber projectiles.
4. Both players vote for Dust Canyon, Storm Harbour, or Moonbase Nine.
5. Both players confirm the second Ready step.
6. The game enters fullscreen and alternates five shots per player.
7. Destroying the enemy commander wins immediately. Otherwise, score and remaining commander health decide the result.

Spectators can join after play begins. A player leaving during active battle forfeits to the remaining player.

## Controls

- Drag backwards from your launcher and release to fire.
- Tap **Activate ability** while a Splitter or Bomber is in flight.
- Boulder has no activated ability and deals heavier direct impact damage.

## Version 1.1.1 changes

- Added the approved Pocket Siege splash artwork as a lightweight local JPEG asset.
- Restyled the open, lobby, setup, play, and result screens to the PocketArcade visual and interaction language.
- Kept the battlefield, turn information, and current controls together without scrolling during play.
- Reordered lobby and setup player cards so the local player appears first.
- Added neutral avatar pills for spectators and simplified empty seats to **Open Seat**.
- Reworked inactive controls so their material identity remains visible rather than applying a grey overlay.
- Reduced the authoritative simulation rate from 20 Hz to 15 Hz for scheduler headroom.
- Removed the setup-time all-body support scan. The fixed fortress layout assigns its support links directly as each block is created.
- Moved battlefield creation out of the second `battle_ready` command. A small battle shell, the first fort, the second fort, and final activation are completed as four bounded tick steps.
- Removed repeated full support scans from the physics hot path. Settled bodies check only their short, explicit supporter lists.
- Replaced static all-pairs collision work with a reusable 10-cell spatial broad phase. Moving bodies check only nearby cell occupants, static-static pairs are skipped, and dynamic-dynamic pairs are processed only once.

## Technical profile

- Authoritative Lua simulation at 15 Hz with automatic PocketArcade snapshots.
- Responsive HTML canvas presentation, including PocketArcade fullscreen mode.
- Twenty-four bounded fortress bodies and at most three simultaneous projectiles.
- Local package assets only; no remote fonts, libraries, analytics, network requests, or additional WebSocket.
- Scoped styles and complete listener, animation, fullscreen, and subscription cleanup.
- Active-match ID and snapshot-revision checks on all incoming envelopes.
- Reconnect and controller-transfer recovery through requested authoritative snapshots.

## Checks performed

- Manifest JSON parsed successfully and referenced package paths exist.
- Browser client passed `node --check`.
- Lua source passed a Lua 5.3 bytecode-parser syntax check.
- A Lua harness verified that the second battle-ready command only arms the build, that four bounded tick steps create all 24 bodies, and that every direct support link resolves to a valid body.
- A 240-tick stress run forced all 24 fortress bodies into motion at once and completed without an error in the revised bounded physics path.

The final acceptance test still needs to run on the target ESP32 with separate profiles, spectators, reconnect grace, controller transfer, weak connections, long play, and serial Lua timing/memory logs. A repeatable tick-overrun warning remains a release blocker.
